/**
 * MarkTab — Bookmark Launcher
 * Search-first, keyboard-driven, paper-calm new tab.
 */

// ─── Theme Registry ──────────────────────────────────────────
const THEMES = [
  { id: 'light',  name: 'Light',  desc: 'Soft daylight workspace' },
  { id: 'dark',   name: 'Dark',   desc: 'Graphite focus mode' },
  { id: 'system', name: 'System', desc: 'Follow your device' }
];

// ─── Defaults ────────────────────────────────────────────────
const DEFAULTS = {
  hiddenFolderIds: [],
  pinnedBookmarkUrls: [],
  recentUrls: [],
  theme: 'light',
  homeShowRecent: true,
  homeRecentCount: 8
};

// ─── State ───────────────────────────────────────────────────
let settings = {};
let allBookmarks = [];
let bookmarkTree = [];
let flatFolders = [];
let uncategorizedBookmarks = [];

const FALLBACK_MESSAGES = {
  searchBookmarksAndFolders: '搜索书签、文件夹或输入网址',
  search: '搜索',
  hintOpen: '打开',
  hintWeb: '搜索网页',
  hintClose: '关闭',
  settingsSaved: '设置已保存',
  loadingBookmarks: '正在加载书签…',
  untitled: '未命名',
  pinABookmark: '固定常用',
  fromAnyFolder: '从任意文件夹固定',
  importBookmarks: '导入书签',
  fromBrowser: '从浏览器导入',
  recentFirst: '最近优先',
  quickAccess: '快速访问',
  browseFolders: '浏览文件夹',
  organizeLinks: '整理链接',
  noRecentBookmarksYet: '暂无最近访问',
  recentEmptyDescription: '打开书签后，访问记录会显示在这里',
  viewAll: '查看全部',
  recent: '最近访问',
  yesterday: '昨天',
  home: '首页',
  folders: '文件夹',
  bookmarkCount: '$1 个书签',
  bookmarkCountPlural: '$1 个书签',
  searchInFolderNamed: '在 $1 中搜索…',
  searchInFolder: '在当前文件夹中搜索',
  listView: '列表视图',
  thisFolderIsEmpty: '当前文件夹暂无书签',
  folderEmptyDescription: '你可以从浏览器书签中移动或添加内容',
  pin: '固定',
  unpin: '取消固定',
  pinned: '已固定',
  unpinned: '已取消固定',
  startTypingToSearch: '输入内容开始搜索',
  searchWebFor: '搜索网页：$1',
  searchFailed: '搜索失败',
  theme: '主题：$1',
  themeLight: '浅色',
  themeDark: '深色',
  themeSystem: '跟随系统',
  themeToggle: '切换主题',
  newTabPage: '新标签页',
  commonBookmarks: '常用书签',
  bookmarkStats: '书签统计',
  productSubtitle: '书签，触手可及',
  bookmarksUnit: '个书签',
  foldersUnit: '个文件夹',
  appearance: '外观',
  hide: '隐藏',
  show: '显示',
  greetingLate: '夜深了',
  greetingMorning: '早上好',
  greetingNoon: '中午好',
  greetingAfternoon: '下午好',
  greetingEvening: '晚上好'
};

// ─── DOM refs ────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const el = {
  homeView:            $('homeView'),
  folderView:          $('folderView'),
  homeClock:           $('homeClock'),
  homeDate:            $('homeDate'),
  homeSearchInput:     $('homeSearchInput'),
  homeSearchShortcut:  $('homeSearchShortcut'),
  homeGreeting:        $('homeGreeting'),
  homeHero:            $('homeHero'),
  homeSections:        $('homeSections'),
  homePinnedGrid:      $('homePinnedGrid'),
  homeRecentGrid:      $('homeRecentGrid'),
  homeFolderPills:     $('homeFolderPills'),
  homeLoading:         $('homeLoading'),
  homeFab:             $('homeFab'),
  homeSidebarFolders:  $('homeSidebarFolders'),
  homeSidebarFolderTotal: $('homeSidebarFolderTotal'),
  homeStatsBookmarks:  $('homeStatsBookmarks'),
  homeStatsFolders:    $('homeStatsFolders'),
  homeSidebarSettingsBtn: $('homeSidebarSettingsBtn'),
  homeSidebarThemeBtn: $('homeSidebarThemeBtn'),
  folderSidebar:       $('folderSidebar'),
  sidebarNav:          $('sidebarNav'),
  sidebarHomeBtn:      $('sidebarHomeBtn'),
  folderSidebarHomeBtn: $('folderSidebarHomeBtn'),
  folderSidebarSettingsBtn: $('folderSidebarSettingsBtn'),
  folderSidebarThemeBtn: $('folderSidebarThemeBtn'),
  folderSidebarFolderTotal: $('folderSidebarFolderTotal'),
  folderStatsBookmarks: $('folderStatsBookmarks'),
  folderStatsFolders: $('folderStatsFolders'),
  folderSearchInput:   $('folderSearchInput'),
  folderTitle:         $('folderTitle'),
  folderCount:         $('folderCount'),
  folderContent:       $('folderContent'),
  folderBookmarksGrid: $('folderBookmarksGrid'),
  folderEmpty:         $('folderEmpty'),
  settingsPanelOverlay: $('settingsPanelOverlay'),
  settingsPanel:       $('settingsPanel'),
  settingsPanelClose:  $('settingsPanelClose'),
  themeOptions:        $('themeOptions'),
  settingsFolderList:  $('settingsFolderList'),
  searchPanel:         $('searchPanel'),
  searchPanelOverlay:  $('searchPanelOverlay'),
  searchPanelInput:    $('searchPanelInput'),
  searchPanelClose:    $('searchPanelClose'),
  searchPanelResults:  $('searchPanelResults'),
  searchBookmarkItems: $('searchBookmarkItems'),
  searchFolderItems:   $('searchFolderItems'),
  searchWebItem:       $('searchWebItem'),
  searchEmpty:         $('searchEmpty'),
  toastContainer:      $('toastContainer')
};

// ─── Helpers ─────────────────────────────────────────────────
function escapeHtml(text) {
  if (!text) return '';
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}

function getDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); }
  catch { return url || ''; }
}

function getFaviconUrl(pageUrl, size = 32) {
  if (!pageUrl || typeof chrome === 'undefined' || !chrome.runtime) return '';
  try {
    const u = new URL(chrome.runtime.getURL('/_favicon/'));
    u.searchParams.set('pageUrl', pageUrl);
    u.searchParams.set('size', String(size));
    return u.toString();
  } catch { return ''; }
}

function highlightMatch(text, query) {
  const safe = escapeHtml(text);
  if (!query) return safe;
  const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return safe.replace(new RegExp(`(${escaped})`, 'gi'), '<mark>$1</mark>');
}

function debounce(fn, ms) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), ms);
  };
}

function getUiLocale() {
  const language = typeof chrome !== 'undefined' && chrome.i18n?.getUILanguage
    ? chrome.i18n.getUILanguage()
    : navigator.language;
  return language || 'en';
}

function getShortcutHint() {
  const platform = navigator.userAgentData?.platform || navigator.platform || navigator.userAgent || '';
  return /\b(Mac|iPhone|iPad|iPod)\b/.test(platform) ? '⌘ K' : 'Ctrl K';
}

function msg(key, substitutions = []) {
  const values = Array.isArray(substitutions) ? substitutions : [substitutions];
  if (typeof chrome !== 'undefined' && chrome.i18n?.getMessage) {
    const translated = chrome.i18n.getMessage(key, values);
    if (translated) return translated;
  }
  return values.reduce(
    (text, value, index) => text.replaceAll(`$${index + 1}`, String(value)),
    FALLBACK_MESSAGES[key] || key
  );
}

function bookmarkCountLabel(count) {
  return msg(count === 1 ? 'bookmarkCount' : 'bookmarkCountPlural', String(count));
}

function localizeDocument() {
  const locale = getUiLocale().replace('_', '-');
  document.documentElement.lang = locale.startsWith('zh') ? 'zh-CN' : 'en';

  document.querySelectorAll('[data-i18n]').forEach(node => {
    node.textContent = msg(node.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(node => {
    node.setAttribute('placeholder', msg(node.dataset.i18nPlaceholder));
  });
  document.querySelectorAll('[data-i18n-aria-label]').forEach(node => {
    node.setAttribute('aria-label', msg(node.dataset.i18nAriaLabel));
  });
  document.querySelectorAll('[data-i18n-title]').forEach(node => {
    node.setAttribute('title', msg(node.dataset.i18nTitle));
  });
}

// ─── Toast ───────────────────────────────────────────────────
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  toast.setAttribute('role', 'status');
  toast.setAttribute('aria-live', 'polite');
  el.toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';
    setTimeout(() => toast.remove(), 300);
  }, 2200);
}

// ─── Time ────────────────────────────────────────────────────
function updateTime() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  el.homeClock.textContent = `${h}:${m}`;
  el.homeDate.textContent = now.toLocaleDateString(getUiLocale(), {
    month: 'long', day: 'numeric', weekday: 'long'
  }).replace(/,\s*/g, ' ');
  // Greeting
  const hour = now.getHours();
  let greeting;
  if (hour < 6) greeting = msg('greetingLate');
  else if (hour < 12) greeting = msg('greetingMorning');
  else if (hour < 14) greeting = msg('greetingNoon');
  else if (hour < 18) greeting = msg('greetingAfternoon');
  else greeting = msg('greetingEvening');
  if (el.homeGreeting) el.homeGreeting.textContent = greeting;
}

// ─── Theme ───────────────────────────────────────────────────
let systemWatcher = null;
let systemCallback = null;

function applyTheme(themeId) {
  const theme = THEMES.find(t => t.id === themeId) || THEMES[0];
  settings.theme = theme.id;

  // Stop previous system watcher
  if (systemWatcher && systemCallback) {
    systemWatcher.removeEventListener('change', systemCallback);
    systemWatcher = null;
    systemCallback = null;
  }

  if (theme.id === 'system') {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    document.documentElement.dataset.theme = mq.matches ? 'dark' : 'light';
    systemCallback = e => {
      document.documentElement.dataset.theme = e.matches ? 'dark' : 'light';
    };
    mq.addEventListener('change', systemCallback);
    systemWatcher = mq;
  } else {
    document.documentElement.dataset.theme = theme.id;
  }
}

// ─── Settings ────────────────────────────────────────────────
async function loadSettings() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      const result = await chrome.storage.sync.get(['markTabSettings']);
      settings = { ...DEFAULTS, ...(result.markTabSettings || {}) };
      // migrate legacy
      if (!result.markTabSettings) {
        const legacy = await chrome.storage.sync.get(['rainbowBookmarkSettings']);
        if (legacy.rainbowBookmarkSettings) {
          settings = { ...DEFAULTS, ...legacy.rainbowBookmarkSettings };
          delete settings.defaultEngine;
          await saveSettingsSilent();
        }
      }
    } else {
      settings = { ...DEFAULTS };
    }
  } catch { settings = { ...DEFAULTS }; }
}

async function saveSettingsSilent() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      await chrome.storage.sync.set({ markTabSettings: settings });
    }
  } catch {}
}

async function saveSettings() {
  await saveSettingsSilent();
  showToast(msg('settingsSaved'));
}

// ─── Bookmark Manager ────────────────────────────────────────
function flattenFolders(tree) {
  const folders = [];
  function traverse(node, depth = 0, parentPath = []) {
    if (node.children && !node.url) {
      const directBm = node.children.filter(c => c.url);
      const currentPath = [...parentPath.map(p => p.title), node.title || msg('untitled')];
      const pathIds = [...parentPath.map(p => p.id), node.id];
      const displayPath = currentPath.slice(2).filter(Boolean);
      folders.push({
        id: node.id, title: node.title || msg('untitled'), depth,
        displayDepth: Math.max(depth - 2, 0),
        path: currentPath, pathIds, displayPath: displayPath.length ? displayPath : [node.title || msg('untitled')],
        pathString: currentPath.join(' / '), bookmarks: directBm,
        bookmarkCount: countAllBookmarks(node), parentId: node.parentId,
        children: node.children.filter(c => c.children).map(c => c.id),
        isSystemFolder: depth <= 1
      });
      node.children.forEach(child => {
        if (child.children) traverse(child, depth + 1, [...parentPath, { id: node.id, title: node.title || msg('untitled') }]);
      });
    }
  }
  tree.forEach(root => traverse(root, 0, []));
  return folders;
}

function countAllBookmarks(folder) {
  let count = 0;
  if (folder.children) {
    folder.children.forEach(child => {
      if (child.url) count++;
      else if (child.children) count += countAllBookmarks(child);
    });
  }
  return count;
}

function getUserFolders(includeHidden = false) {
  return flatFolders.filter(f => !f.isSystemFolder && (includeHidden || isFolderVisible(f.id)));
}

function isFolderVisible(id) {
  return !settings.hiddenFolderIds.includes(id);
}

function toggleFolderVisibility(id) {
  const idx = settings.hiddenFolderIds.indexOf(id);
  if (idx > -1) settings.hiddenFolderIds.splice(idx, 1);
  else settings.hiddenFolderIds.push(id);
  saveSettingsSilent();
}

function isPinned(url) {
  return Boolean(url && settings.pinnedBookmarkUrls.includes(url));
}

function togglePin(url) {
  if (!url) return;
  const idx = settings.pinnedBookmarkUrls.indexOf(url);
  if (idx === -1) settings.pinnedBookmarkUrls.push(url);
  else settings.pinnedBookmarkUrls.splice(idx, 1);
  saveSettingsSilent();
  return idx === -1; // true = now pinned
}

function getPinnedBookmarks() {
  const seen = new Set();
  return allBookmarks.filter(b => {
    if (!b.url || seen.has(b.url) || !isPinned(b.url)) return false;
    seen.add(b.url);
    return true;
  });
}

function getRecentBookmarks(count = 8) {
  const recent = [];
  const seen = new Set();
  for (const url of settings.recentUrls) {
    if (recent.length >= count) break;
    const bm = allBookmarks.find(b => b.url === url);
    if (bm && !seen.has(url)) { recent.push(bm); seen.add(url); }
  }
  return recent;
}

function trackVisit(url) {
  if (!url) return;
  settings.recentUrls = [url, ...settings.recentUrls.filter(u => u !== url)].slice(0, 50);
  saveSettingsSilent();
}

function searchBookmarks(query) {
  const q = query.toLowerCase().trim();
  if (!q) return { bookmarks: [], folders: [] };
  const bmResults = allBookmarks.filter(b =>
    (b.title && b.title.toLowerCase().includes(q)) ||
    (b.url && b.url.toLowerCase().includes(q))
  );
  const folderResults = getUserFolders(true).filter(f =>
    f.title.toLowerCase().includes(q)
  );
  return { bookmarks: bmResults.slice(0, 12), folders: folderResults.slice(0, 6) };
}

async function loadBookmarks() {
  try {
    el.homeLoading.style.display = 'flex';
    if (typeof chrome !== 'undefined' && chrome.bookmarks) {
      const tree = await chrome.bookmarks.getTree();
      bookmarkTree = tree;
      flatFolders = flattenFolders(tree);
      allBookmarks = [];
      flatFolders.forEach(f => { allBookmarks = allBookmarks.concat(f.bookmarks); });
      uncategorizedBookmarks = getUserFolders(true)
        .filter(f => f.isSystemFolder)
        .flatMap(f => f.bookmarks);
      renderHome();
      el.homeLoading.style.display = 'none';
    } else {
      showMockData();
    }
  } catch { showMockData(); }
}

// ─── Mock Data ──────────────────────────────────────────────
function showMockData() {
  const mockTree = [{
    id: '0', title: '', children: [{
      id: '1', title: 'Bookmarks Bar', children: [
        { id: 'b1', title: 'GitHub', url: 'https://github.com' },
        { id: 'b2', title: 'Notion', url: 'https://notion.so' },
        { id: 'b3', title: 'Figma', url: 'https://figma.com' },
        { id: 'b4', title: 'ChatGPT', url: 'https://chat.openai.com' },
        { id: 'b5', title: 'Claude', url: 'https://claude.ai' },
        { id: 'b6', title: 'Linear', url: 'https://linear.app' },
        { id: 'b7', title: 'Vercel', url: 'https://vercel.com' },
        {
          id: 'f1', title: 'Dev Tools', children: [
            { id: 'b8', title: 'MDN', url: 'https://developer.mozilla.org' },
            { id: 'b9', title: 'Stack Overflow', url: 'https://stackoverflow.com' },
            { id: 'b10', title: 'Can I Use', url: 'https://caniuse.com' }
          ]
        },
        {
          id: 'f2', title: 'Design', children: [
            { id: 'b11', title: 'Dribbble', url: 'https://dribbble.com' },
            { id: 'b12', title: 'Awwwards', url: 'https://awwwards.com' }
          ]
        }
      ]
    }, {
      id: '2', title: 'Other Bookmarks', children: [
        { id: 'b13', title: 'YouTube', url: 'https://youtube.com' },
        { id: 'b14', title: 'Reddit', url: 'https://reddit.com' }
      ]
    }]
  }];
  bookmarkTree = mockTree;
  flatFolders = flattenFolders(mockTree);
  allBookmarks = [];
  flatFolders.forEach(f => { allBookmarks = allBookmarks.concat(f.bookmarks); });
  uncategorizedBookmarks = [];
  el.homeLoading.style.display = 'none';
  renderHome();
}

// ─── Home View ──────────────────────────────────────────────
function renderHome() {
  renderHomeSidebar();
  renderHomePinned();
  renderHomeRecent();
  renderHomeFolders();
}

function renderHomeSidebar() {
  const folders = getUserFolders(false)
    .slice()
    .sort((a, b) => (b.bookmarkCount - a.bookmarkCount) || a.title.localeCompare(b.title, getUiLocale()));
  el.homeSidebarFolders.innerHTML = folders.map(folder => `
    <button class="home-sidebar-folder" type="button" data-folder-id="${escapeHtml(folder.id)}" title="${escapeHtml(folder.pathString)}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" aria-hidden="true">
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
      </svg>
      <span class="home-sidebar-folder-name">${escapeHtml(folder.title)}</span>
      <span class="home-sidebar-folder-count">${folder.bookmarkCount}</span>
    </button>
  `).join('');

  el.homeSidebarFolderTotal.textContent = String(getUserFolders(false).length);
  el.homeStatsBookmarks.textContent = String(allBookmarks.length);
  el.homeStatsFolders.textContent = String(getUserFolders(false).length);

  el.homeSidebarFolders.querySelectorAll('.home-sidebar-folder').forEach(btn => {
    btn.addEventListener('click', () => openFolderView(btn.dataset.folderId));
  });
}

function renderHomePinned() {
  const pinned = getPinnedBookmarks();
  let html = pinned.map(b => createHomeCard(b)).join('');
  const pinnedCountClass = `pinned-count-${Math.min(pinned.length, 8)}`;
  const contentStateClass = pinned.length > 1 ? 'has-multiple-pins' : pinned.length > 0 ? 'has-pinned-content' : 'is-empty';
  el.homePinnedGrid.className = `home-card-grid home-pinned-grid ${pinnedCountClass} ${contentStateClass}`;

  if (pinned.length === 0) {
    const placeholders = [
      [msg('pinABookmark'), msg('fromAnyFolder'), '<path d="M6 4.75A1.75 1.75 0 0 1 7.75 3h8.5A1.75 1.75 0 0 1 18 4.75V21l-6-3.7L6 21z"></path>'],
      [msg('importBookmarks'), msg('fromBrowser'), '<path d="M12 3v11"></path><path d="m8 10 4 4 4-4"></path><path d="M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"></path>'],
      [msg('recentFirst'), msg('quickAccess'), '<circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5V12l3 2"></path>'],
      [msg('browseFolders'), msg('organizeLinks'), '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v7A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5z"></path>']
    ];
    const placeholder = ([title, meta, icon]) => `
      <div class="home-card-placeholder empty-pin-card">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
          ${icon}
        </svg>
        <span class="empty-pin-title">${title}</span>
        <span class="empty-pin-meta">${meta}</span>
      </div>`;
    html = placeholders.map(item => placeholder(item)).join('');
  }
  el.homePinnedGrid.innerHTML = html;
  afterRenderCards(el.homePinnedGrid);
}

function renderHomeRecent() {
  if (!settings.homeShowRecent) { el.homeRecentGrid.innerHTML = ''; return; }
  const allRecent = getRecentBookmarks(settings.homeRecentCount);
  if (!allRecent.length) {
    el.homeRecentGrid.className = 'home-recent-list';
    el.homeRecentGrid.innerHTML = `
      <div class="recent-empty">
        <span class="recent-empty-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5V12l3 2"></path>
          </svg>
        </span>
        <span class="recent-empty-copy">
          <strong>${escapeHtml(msg('noRecentBookmarksYet'))}</strong>
          <span>${escapeHtml(msg('recentEmptyDescription'))}</span>
        </span>
      </div>`;
    const existing = el.homeRecentGrid.closest('.home-section')?.querySelector('.home-recent-view-all');
    if (existing) existing.remove();
    return;
  }
  const showCount = Math.min(allRecent.length, 6);
  const recent = allRecent.slice(0, showCount);

  el.homeRecentGrid.className = 'home-recent-list';
  el.homeRecentGrid.innerHTML = `<div class="home-recent-surface">${recent.map(createRecentRow).join('')}</div>`;
  afterRenderRecent();

  const section = el.homeRecentGrid.closest('.home-section');
  const header = section?.querySelector('.section-header');
  if (!header) return;
  const existing = header.querySelector('.home-recent-view-all');
  if (allRecent.length > 4) {
    if (!existing) {
      const btn = document.createElement('button');
      btn.className = 'home-recent-view-all';
      btn.textContent = msg('viewAll');
      btn.addEventListener('click', () => {
        const recent20 = getRecentBookmarks(20);
        openFolderViewForBookmarks(recent20, msg('recent'));
      });
      header.appendChild(btn);
    }
  } else if (existing) {
    existing.remove();
  }
}

function createRecentRow(bookmark) {
  const domain = getDomain(bookmark.url);
  const title = bookmark.title || msg('untitled');
  const initial = title.charAt(0).toUpperCase();
  const faviconUrl = getFaviconUrl(bookmark.url, 32);
  const timeLabel = formatRecentTime(bookmark.dateAdded);
  return `
    <a class="home-recent-item" href="${escapeHtml(bookmark.url)}" data-url="${escapeHtml(bookmark.url)}" title="${escapeHtml(title)}">
      <div class="home-recent-favicon">
        ${faviconUrl ? `<img class="home-recent-favicon-img" src="${escapeHtml(faviconUrl)}" alt="" loading="lazy" width="16" height="16">` : ''}
        <span class="home-recent-favicon-letter">${escapeHtml(initial)}</span>
      </div>
      <div class="home-recent-item-content">
        <div class="home-recent-item-title">${escapeHtml(title)}</div>
        <div class="home-recent-item-domain">${escapeHtml(domain)}</div>
      </div>
      ${timeLabel ? `<span class="home-recent-time">${escapeHtml(timeLabel)}</span>` : ''}
    </a>
  `;
}

function formatRecentTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return '';
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const dayDiff = Math.round((startToday - startDate) / 86400000);
  if (dayDiff === 0) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  }
  if (dayDiff === 1) return msg('yesterday');
  if (dayDiff > 1 && dayDiff < 7) return `${dayDiff}d`;
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function afterRenderRecent() {
  el.homeRecentGrid.querySelectorAll('.home-recent-favicon-img').forEach(img => {
    const wrapper = img.closest('.home-recent-favicon');
    img.addEventListener('load', () => wrapper.classList.add('loaded'), { once: true });
    img.addEventListener('error', () => { wrapper.classList.remove('loaded'); img.remove(); }, { once: true });
    if (img.complete && img.naturalWidth > 0) wrapper.classList.add('loaded');
  });
  el.homeRecentGrid.querySelectorAll('.home-recent-item').forEach(item => {
    item.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey) return;
      e.preventDefault();
      trackVisit(item.dataset.url);
      window.location.href = item.href;
    });
  });
}

function openFolderViewForBookmarks(bookmarks, title) {
  activeFolderId = '__recent';
  renderSidebar();
  renderFolderContentForBookmarks(bookmarks, title);
  showView('folder');
}

function renderHomeFolders() {
  const folders = getUserFolders(false)
    .slice()
    .sort((a, b) => (b.bookmarkCount - a.bookmarkCount) || a.title.localeCompare(b.title, getUiLocale()));
  el.homeFolderPills.innerHTML = folders.map(f => {
    const meta = bookmarkCountLabel(f.bookmarkCount);
    return `
    <button class="folder-pill" data-folder-id="${escapeHtml(f.id)}" title="${escapeHtml(f.pathString)}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16" aria-hidden="true">
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
      </svg>
      <span class="folder-pill-body">
        <span class="folder-pill-title">${escapeHtml(f.title)}</span>
        <span class="folder-pill-meta">${escapeHtml(meta)}</span>
      </span>
    </button>
  `;
  }).join('');
  el.homeFolderPills.querySelectorAll('.folder-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      openFolderView(btn.dataset.folderId);
    });
  });
}

function createHomeCard(bookmark) {
  const domain = getDomain(bookmark.url);
  const title = bookmark.title || msg('untitled');
  const initial = title.charAt(0).toUpperCase();
  const faviconUrl = getFaviconUrl(bookmark.url, 64);
  const pinned = isPinned(bookmark.url);
  return `
    <a class="home-card" href="${escapeHtml(bookmark.url)}" data-url="${escapeHtml(bookmark.url)}" title="${escapeHtml(title)}">
      <div class="home-card-favicon">
        ${faviconUrl ? `<img class="home-card-favicon-img" src="${escapeHtml(faviconUrl)}" alt="" loading="lazy" width="24" height="24">` : ''}
        <span class="home-card-favicon-letter">${escapeHtml(initial)}</span>
      </div>
      <div class="home-card-copy">
        <span class="home-card-title">${escapeHtml(title)}</span>
        <span class="home-card-domain">${escapeHtml(domain)}</span>
      </div>
    </a>
  `;
}

function afterRenderCards(container) {
  container.querySelectorAll('.home-card-favicon-img').forEach(img => {
    const wrapper = img.closest('.home-card-favicon');
    img.addEventListener('load', () => wrapper.classList.add('loaded'), { once: true });
    img.addEventListener('error', () => { wrapper.classList.remove('loaded'); img.remove(); }, { once: true });
    if (img.complete && img.naturalWidth > 0) wrapper.classList.add('loaded');
  });
  container.querySelectorAll('.home-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey) return;
      e.preventDefault();
      trackVisit(card.dataset.url);
      window.location.href = card.href;
    });
  });
}

// ─── Folder View ────────────────────────────────────────────
let activeFolderId = null;

function openFolderView(folderId) {
  activeFolderId = folderId;
  renderSidebar();
  renderFolderContent(folderId);
  showView('folder');
}

function renderSidebar() {
  const folders = getUserFolders(false);

  el.sidebarNav.innerHTML = folders.map(createSidebarFolderItem).join('');
  el.folderSidebarFolderTotal.textContent = String(folders.length);
  el.folderStatsBookmarks.textContent = String(allBookmarks.length);
  el.folderStatsFolders.textContent = String(folders.length);

  document.querySelectorAll('[data-folder-nav]').forEach(item => {
    item.classList.toggle('active', item.dataset.folderNav === 'recent' && activeFolderId === '__recent');
  });

  document.querySelectorAll('[data-folder-view-mode]').forEach(button => {
    button.addEventListener('click', () => {
      const listMode = button.dataset.folderViewMode === 'list';
      el.folderBookmarksGrid.classList.toggle('list-view', listMode);
      document.querySelectorAll('[data-folder-view-mode]').forEach(item => {
        item.classList.toggle('active', item === button);
      });
    });
  });

  el.sidebarNav.querySelectorAll('.sidebar-nav-item').forEach(item => {
    item.addEventListener('click', () => {
      if (item.dataset.folderId) {
        openFolderView(item.dataset.folderId);
      }
    });
  });
}

function createSidebarFolderItem(folder) {
  const isActive = activeFolderId === folder.id;
  const isHidden = !isFolderVisible(folder.id);
  return `
    <button class="home-sidebar-folder sidebar-nav-item ${isActive ? 'active' : ''} ${isHidden ? 'hidden' : ''}" data-folder-id="${escapeHtml(folder.id)}" title="${escapeHtml(folder.title)}">
      <svg class="sidebar-folder-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18" aria-hidden="true">
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
      </svg>
      <span class="sidebar-folder-name">${escapeHtml(folder.title)}</span>
      <span class="sidebar-folder-count">${folder.bookmarkCount}</span>
    </button>
  `;
}

function renderFolderContent(folderId) {
  const folder = flatFolders.find(f => f.id === folderId);
  if (!folder) return;
  renderFolderContentForBookmarks(folder.bookmarks, folder.title, folder.displayPath.join(' / '));
}

function renderFolderContentForBookmarks(bookmarks, title, breadcrumb = '') {
  el.folderTitle.textContent = title;
  el.folderCount.textContent = bookmarkCountLabel(bookmarks.length);
  el.folderSearchInput.placeholder = msg('searchInFolder');

  if (!bookmarks.length) {
    el.folderBookmarksGrid.innerHTML = '';
    el.folderEmpty.style.display = 'flex';
    return;
  }
  el.folderEmpty.style.display = 'none';
  el.folderBookmarksGrid.innerHTML = bookmarks.map(b => createFolderCard(b)).join('');
  afterRenderFolderCards();
}

function createFolderCard(bookmark) {
  const domain = getDomain(bookmark.url);
  const title = bookmark.title || msg('untitled');
  const initial = title.charAt(0).toUpperCase();
  const faviconUrl = getFaviconUrl(bookmark.url, 64);
  const pinned = isPinned(bookmark.url);
  return `
    <div class="folder-card" data-url="${escapeHtml(bookmark.url)}">
      <button class="folder-card-pin ${pinned ? 'pinned' : ''}" data-url="${escapeHtml(bookmark.url)}" aria-label="${pinned ? msg('unpin') : msg('pin')}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" aria-hidden="true">
          <path d="M12 17v5"></path><path d="M5 17h14"></path>
          <path d="M15 3.6 20.4 9l-3 3 1.1 4H5.5l1.1-4-3-3L9 3.6"></path>
        </svg>
      </button>
      <a class="folder-card-link" href="${escapeHtml(bookmark.url)}" data-url="${escapeHtml(bookmark.url)}">
        <div class="folder-card-favicon">
          ${faviconUrl ? `<img class="folder-card-favicon-img" src="${escapeHtml(faviconUrl)}" alt="" loading="lazy" width="24" height="24">` : ''}
          <span class="folder-card-favicon-letter">${escapeHtml(initial)}</span>
        </div>
        <span class="folder-card-title">${escapeHtml(title)}</span>
        <span class="folder-card-domain">${escapeHtml(domain)}</span>
      </a>
    </div>
  `;
}

function afterRenderFolderCards() {
  el.folderBookmarksGrid.querySelectorAll('.folder-card-favicon-img').forEach(img => {
    const wrapper = img.closest('.folder-card-favicon');
    img.addEventListener('load', () => wrapper.classList.add('loaded'), { once: true });
    img.addEventListener('error', () => { wrapper.classList.remove('loaded'); img.remove(); }, { once: true });
    if (img.complete && img.naturalWidth > 0) wrapper.classList.add('loaded');
  });
  el.folderBookmarksGrid.querySelectorAll('.folder-card-link').forEach(link => {
    link.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey) return;
      e.preventDefault();
      trackVisit(link.dataset.url);
      window.location.href = link.href;
    });
  });
  el.folderBookmarksGrid.querySelectorAll('.folder-card-pin').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      togglePin(btn.dataset.url);
      btn.classList.toggle('pinned');
      btn.setAttribute('aria-label', btn.classList.contains('pinned') ? msg('unpin') : msg('pin'));
      renderHome();
      showToast(btn.classList.contains('pinned') ? msg('pinned') : msg('unpinned'));
    });
  });
}

// ─── Search result favicon loading ────────────────────────
function setupSearchFavicons() {
  document.querySelectorAll('.search-result-favicon-img').forEach(img => {
    const wrapper = img.closest('.search-result-favicon');
    if (!wrapper) return;
    img.addEventListener('load', () => wrapper.classList.add('loaded'), { once: true });
    img.addEventListener('error', () => { wrapper.classList.remove('loaded'); img.remove(); }, { once: true });
    if (img.complete && img.naturalWidth > 0) wrapper.classList.add('loaded');
  });
}

// ─── Folder search filter ──────────────────────────────────
function filterFolderBookmarks(query) {
  const q = query.toLowerCase().trim();
  if (activeFolderId === '__recent') {
    const bookmarks = getRecentBookmarks(100);
    const filtered = q ? bookmarks.filter(b =>
      (b.title && b.title.toLowerCase().includes(q)) ||
      (b.url && b.url.toLowerCase().includes(q))
    ) : bookmarks;
    renderFolderContentForBookmarks(filtered, msg('recent'));
    return;
  }
  const folder = flatFolders.find(f => f.id === activeFolderId);
  if (!folder) return;
  const bookmarks = q ? folder.bookmarks.filter(b =>
    (b.title && b.title.toLowerCase().includes(q)) ||
    (b.url && b.url.toLowerCase().includes(q))
  ) : folder.bookmarks;
  renderFolderContentForBookmarks(bookmarks, folder.title);
  if (!q) el.folderSearchInput.placeholder = msg('searchInFolder');
}

// ─── Search Panel (Spotlight Style) ─────────────────────────
let searchResultIndex = -1;
let searchResults = [];

function openSearch() {
  el.searchPanelOverlay.style.display = 'flex';
  el.searchPanel.style.display = 'flex';
  el.searchPanelInput.value = '';
  el.searchPanelInput.focus();
  searchResultIndex = -1;
  searchResults = [];
  el.searchBookmarkItems.innerHTML = '';
  el.searchFolderItems.innerHTML = '';
  el.searchWebItem.innerHTML = '';
  el.searchEmpty.style.display = 'flex';
  el.searchEmpty.querySelector('p').textContent = msg('startTypingToSearch');
  document.body.classList.add('search-open');
}

function closeSearch() {
  el.searchPanelOverlay.style.display = 'none';
  el.searchPanel.style.display = 'none';
  document.body.classList.remove('search-open');
  searchResultIndex = -1;
  searchResults = [];
}

function handleSearchInput() {
  const query = el.searchPanelInput.value;
  if (!query.trim()) {
    el.searchBookmarkItems.innerHTML = '';
    el.searchFolderItems.innerHTML = '';
    el.searchWebItem.innerHTML = '';
    el.searchEmpty.style.display = 'flex';
    el.searchEmpty.querySelector('p').textContent = msg('startTypingToSearch');
    return;
  }

  el.searchEmpty.style.display = 'none';
  const { bookmarks, folders } = searchBookmarks(query);

  // Render bookmark results
  if (bookmarks.length) {
    el.searchBookmarkItems.innerHTML = bookmarks.map((b, i) => createSearchBookmarkItem(b, query, i)).join('');
  } else {
    el.searchBookmarkItems.innerHTML = '';
  }

  // Render folder results
  if (folders.length) {
    el.searchFolderItems.innerHTML = folders.map((f, i) => createSearchFolderItem(f, query, bookmarks.length + i)).join('');
  } else {
    el.searchFolderItems.innerHTML = '';
  }

  // Setup favicon loading for search results
  setupSearchFavicons();

  // Web search item
  el.searchWebItem.innerHTML = `
    <button class="search-result-item search-web-item" data-index="${bookmarks.length + folders.length}" data-action="web">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18" aria-hidden="true">
        <circle cx="11" cy="11" r="8"></circle>
        <path d="m21 21-4.35-4.35"></path>
      </svg>
      <div class="search-result-content">
        <span class="search-result-title">${escapeHtml(msg('searchWebFor', query.trim()))}</span>
      </div>
    </button>
  `;

  // Collect all result items
  searchResults = [];
  el.searchPanelResults.querySelectorAll('.search-result-item').forEach(item => {
    searchResults.push(item);
  });

  // Auto-highlight first
  searchResultIndex = 0;
  updateSearchHighlight();

  // Update group visibility
  document.querySelectorAll('.search-group').forEach(g => {
    const items = g.querySelector('.search-panel-items');
    g.style.display = items && items.children.length ? 'block' : 'none';
  });
}

function createSearchBookmarkItem(bookmark, query, index) {
  const domain = getDomain(bookmark.url);
  const title = bookmark.title || msg('untitled');
  const initial = title.charAt(0).toUpperCase();
  const faviconUrl = getFaviconUrl(bookmark.url, 32);
  return `
    <button class="search-result-item" data-index="${index}" data-url="${escapeHtml(bookmark.url)}" data-action="bookmark">
      <div class="search-result-favicon">
        ${faviconUrl ? `<img class="search-result-favicon-img" src="${escapeHtml(faviconUrl)}" alt="" loading="lazy" width="16" height="16">` : ''}
        <span class="search-result-favicon-letter">${escapeHtml(initial)}</span>
      </div>
      <div class="search-result-content">
        <span class="search-result-title">${highlightMatch(title, query)}</span>
        <span class="search-result-domain">${highlightMatch(domain, query)}</span>
      </div>
    </button>
  `;
}

function createSearchFolderItem(folder, query, index) {
  return `
    <button class="search-result-item" data-index="${index}" data-folder-id="${escapeHtml(folder.id)}" data-action="folder">
      <div class="search-result-favicon search-result-folder-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="18" height="18" aria-hidden="true">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
        </svg>
      </div>
      <div class="search-result-content">
        <span class="search-result-title">${highlightMatch(folder.title, query)}</span>
        <span class="search-result-domain">${escapeHtml(bookmarkCountLabel(folder.bookmarkCount))}</span>
      </div>
    </button>
  `;
}

function updateSearchHighlight() {
  searchResults.forEach((item, i) => {
    item.classList.toggle('selected', i === searchResultIndex);
  });
  const active = searchResults[searchResultIndex];
  if (active) active.scrollIntoView({ block: 'nearest' });
}

function navigateSearch(direction) {
  if (!searchResults.length) return;
  searchResultIndex = (searchResultIndex + direction + searchResults.length) % searchResults.length;
  updateSearchHighlight();
}

function activateSearchResult() {
  const item = searchResults[searchResultIndex];
  if (!item) return;
  const action = item.dataset.action;
  if (action === 'bookmark') {
    trackVisit(item.dataset.url);
    window.location.href = item.dataset.url;
  } else if (action === 'folder') {
    closeSearch();
    openFolderView(item.dataset.folderId);
  } else if (action === 'web') {
    performWebSearch(el.searchPanelInput.value);
  }
}

async function performWebSearch(query) {
  if (!query.trim()) return;
  if (typeof chrome !== 'undefined' && chrome.search?.query) {
    try {
      await chrome.search.query({ text: query, disposition: 'CURRENT_TAB' });
    } catch { showToast(msg('searchFailed')); }
  } else {
    window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
  }
}

function renderSettingsPanel() {
  const currentTheme = settings.theme;
  el.themeOptions.innerHTML = THEMES.map(theme => `
    <button class="theme-option ${theme.id === currentTheme ? 'active' : ''}" type="button" data-theme-id="${escapeHtml(theme.id)}">
      <span class="theme-option-name">${escapeHtml(msg(`theme${theme.name}`) || theme.name)}</span>
      <span class="theme-option-desc">${escapeHtml(theme.desc)}</span>
    </button>
  `).join('');

  el.settingsFolderList.innerHTML = getUserFolders(true)
    .slice()
    .sort((a, b) => a.title.localeCompare(b.title, getUiLocale()))
    .map(folder => {
      const visible = isFolderVisible(folder.id);
      return `
        <div class="settings-folder-item">
          <span class="settings-folder-name">${escapeHtml(folder.title)}</span>
          <span class="settings-folder-count">${folder.bookmarkCount}</span>
          <button class="settings-folder-toggle" type="button" data-folder-id="${escapeHtml(folder.id)}">${escapeHtml(msg(visible ? 'hide' : 'show'))}</button>
        </div>
      `;
    }).join('');

  el.themeOptions.querySelectorAll('.theme-option').forEach(btn => {
    btn.addEventListener('click', () => {
      applyTheme(btn.dataset.themeId);
      saveSettingsSilent();
      renderSettingsPanel();
    });
  });

  el.settingsFolderList.querySelectorAll('.settings-folder-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      toggleFolderVisibility(btn.dataset.folderId);
      renderHome();
      renderSidebar();
      renderSettingsPanel();
      if (activeFolderId && !isFolderVisible(activeFolderId)) {
        returnHome();
      }
    });
  });
}

function openSettingsPanel() {
  renderSettingsPanel();
  el.settingsPanelOverlay.style.display = 'flex';
  document.body.classList.add('search-open');
}

function closeSettingsPanel() {
  el.settingsPanelOverlay.style.display = 'none';
  document.body.classList.remove('search-open');
}

// ─── Theme Cycle ────────────────────────────────────────────
function cycleTheme() {
  const themeIds = THEMES.map(t => t.id);
  const current = settings.theme;
  const idx = themeIds.indexOf(current);
  const next = themeIds[(idx + 1) % themeIds.length];
  applyTheme(next);
  saveSettingsSilent();
  const names = { light: msg('themeLight'), dark: msg('themeDark'), system: msg('themeSystem') };
  showToast(msg('theme', names[next] || next));
}

// ─── View Manager ───────────────────────────────────────────
function returnHome() {
  renderHome();
  showView('home');
}

function showView(view) {
  el.homeView.style.display = view === 'home' ? '' : 'none';
  el.folderView.style.display = view === 'folder' ? '' : 'none';
  el.homeFab.style.display = window.innerWidth <= 768 && view === 'home' ? 'flex' : 'none';
}

// ─── Event Setup ────────────────────────────────────────────
function setupEvents() {
  if (el.homeSearchShortcut) {
    el.homeSearchShortcut.textContent = getShortcutHint();
  }

  // Home search: click triggers spotlight panel
  el.homeSearchInput.addEventListener('focus', e => {
    e.target.blur();
    openSearch();
  });

  // Folder search — inline filtering
  el.folderSearchInput.addEventListener('input', debounce(function() {
    filterFolderBookmarks(this.value.trim());
  }, 80));
  el.folderSearchInput.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      el.folderSearchInput.value = '';
      filterFolderBookmarks('');
      el.folderSearchInput.blur();
    }
  });

  // Home FAB — cycle theme
  el.homeFab.addEventListener('click', cycleTheme);
  el.homeSidebarThemeBtn.addEventListener('click', cycleTheme);
  el.folderSidebarThemeBtn.addEventListener('click', cycleTheme);
  el.homeSidebarSettingsBtn.addEventListener('click', openSettingsPanel);
  el.folderSidebarSettingsBtn.addEventListener('click', openSettingsPanel);

  // Sidebar home button
  el.sidebarHomeBtn.addEventListener('click', returnHome);
  el.folderSidebarHomeBtn.addEventListener('click', returnHome);

  document.querySelectorAll('[data-home-nav]').forEach(item => {
    item.addEventListener('click', () => {
      const target = item.dataset.homeNav;
      const map = {
        top: el.homeHero,
        pinned: $('homePinnedSection'),
        recent: $('homeRecentSection')
      };
      document.querySelectorAll('[data-home-nav]').forEach(btn => btn.classList.toggle('active', btn === item));
      map[target]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  document.querySelectorAll('[data-folder-nav]').forEach(item => {
    item.addEventListener('click', () => {
      const target = item.dataset.folderNav;
      if (target === 'recent') {
        activeFolderId = '__recent';
        renderFolderContentForBookmarks(getRecentBookmarks(20), msg('recent'));
        renderSidebar();
        return;
      }
      returnHome();
      if (target === 'pinned') {
        requestAnimationFrame(() => $('homePinnedSection')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
      }
    });
  });

  // Sidebar toggle (mobile)
  const sidebarToggle = document.getElementById('sidebarToggle');
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', () => {
      el.folderSidebar.classList.toggle('open');
    });
  }
  // Close sidebar when clicking content on mobile
  el.folderContent?.addEventListener('click', () => {
    if (window.innerWidth <= 768) {
      el.folderSidebar.classList.remove('open');
    }
  });

  // Search panel
  el.searchPanelInput.addEventListener('input', debounce(handleSearchInput, 60));
  el.searchPanelClose.addEventListener('click', closeSearch);
  el.searchPanelOverlay.addEventListener('click', closeSearch);
  el.settingsPanelClose.addEventListener('click', closeSettingsPanel);
  el.settingsPanelOverlay.addEventListener('click', e => {
    if (e.target === el.settingsPanelOverlay) closeSettingsPanel();
  });
  el.settingsPanel.addEventListener('click', e => e.stopPropagation());
  el.searchPanel.addEventListener('click', e => e.stopPropagation());

  // Search result clicks (delegated)
  el.searchPanelResults.addEventListener('click', e => {
    const item = e.target.closest('.search-result-item');
    if (!item) return;
    const idx = parseInt(item.dataset.index);
    if (!isNaN(idx)) { searchResultIndex = idx; activateSearchResult(); }
  });
}

function setupKeyboard() {
  document.addEventListener('keydown', e => {
    const isSearchOpen = el.searchPanel.style.display === 'flex';
    const isSettingsOpen = el.settingsPanelOverlay.style.display === 'flex';

    // / or Cmd+K to open search
    if ((e.key === '/' && !isInputFocused()) ||
        ((e.metaKey || e.ctrlKey) && e.key === 'k')) {
      e.preventDefault();
      if (isSearchOpen) closeSearch();
      else openSearch();
      return;
    }

    if (isSettingsOpen && e.key === 'Escape') {
      e.preventDefault();
      closeSettingsPanel();
      return;
    }

    if (isSearchOpen) {
      switch (e.key) {
        case 'Escape':
          e.preventDefault();
          closeSearch();
          break;
        case 'ArrowDown':
          e.preventDefault();
          navigateSearch(1);
          break;
        case 'ArrowUp':
          e.preventDefault();
          navigateSearch(-1);
          break;
        case 'Enter':
          if (e.shiftKey) {
            // Shift+Enter: web search
            performWebSearch(el.searchPanelInput.value);
          } else {
            e.preventDefault();
            activateSearchResult();
          }
          break;
      }
      return;
    }
  });
}

function isInputFocused() {
  const active = document.activeElement;
  return active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable);
}

// ─── Init ───────────────────────────────────────────────────
async function init() {
  localizeDocument();
  updateTime();
  setInterval(updateTime, 1000);

  await loadSettings();
  applyTheme(settings.theme);
  setupEvents();
  setupKeyboard();
  await loadBookmarks();
  showView('home');
}

// Boot
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
